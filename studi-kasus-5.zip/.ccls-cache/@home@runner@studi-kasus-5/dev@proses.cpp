#include <iostream>
#include <fstream>
#include "../library/proses.h"

int main(){
	Proses proses;
	proses.getData();
  proses.getDataSks();
	proses.toFile();
	return 0;
} 